import 'package:dustbin_app/Models/DustbinLocations.dart';

class Constance{

  static String userID;
  static String userName;
  static double currentLatitude = 0;
  static double currentLongitude = 0;
  static List<DustbinLocations> dustbinLocations = [];

}