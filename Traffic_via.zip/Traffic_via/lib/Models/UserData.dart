class UserData{
  String user_name;
  String email;
  String phone_number;
  String vehicle_number;
  String user_id;

  UserData(this.user_name, this.email, this.phone_number, this.vehicle_number, this.user_id);
}