class DustbinLocations {
  String id;
  String key;
  String latitude;
  String longitude;

  DustbinLocations(this.id, this.key, this.latitude, this.longitude);
}